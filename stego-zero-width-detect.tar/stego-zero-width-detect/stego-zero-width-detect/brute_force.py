import subprocess

file_name = "output.txt"
wordlist_path = "password.txt"

with open(wordlist_path, "r", encoding="utf-8") as f:
    passwords = [line.strip() for line in f]

for password in passwords:
    print(f"[?] Thử với mật khẩu: {password}")

    try:
        process = subprocess.Popen(
            ["stegcloak", "reveal", "-f", file_name],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True
        )

        stdout, stderr = process.communicate(input=password + "\n", timeout=5)

        print("[DEBUG] STDOUT:", stdout)
        print("[DEBUG] STDERR:", stderr)

        if "flag{" in stdout or "flag{" in stderr:
            print(f"[+] Mật khẩu đúng: {password}")
            print("[+] Kết quả giải mã:")
            print(stdout if "flag{" in stdout else stderr)
            break

    except subprocess.TimeoutExpired:
        print("[-] Timeout, bỏ qua...")
        process.kill()
    except Exception as e:
        print(f"[-] Lỗi: {e}")
